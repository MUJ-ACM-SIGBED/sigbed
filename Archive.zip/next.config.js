/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['plus.unsplash.com','i.postimg.cc','images.unsplash.com'],
      },
}

module.exports = nextConfig
